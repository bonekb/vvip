# Instagram Private Tools
Personal Tools to manage Instagram account (nodejs)

How to install 

1. git clone https://github.com/ccocot/Instagram-Private-Tools.git
2. npm install
3. node index.js

List Tools :
1. Unfollow not Followback
2. Unfollow all Following
3. Delete all media
4. Follow Followers Target
5. Bom Like Media Target
6. Follow Account By Hastag

Thank https://github.com/huttarichard/instagram-private-api/ for node module

[![asciicast](https://asciinema.org/a/lA0ISUKy9VIC4XjUqEQOK22rd.png)](https://asciinema.org/a/lA0ISUKy9VIC4XjUqEQOK22rd)
