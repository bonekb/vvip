const inquirer = require('inquirer');
const rp = require('request-promise');
const insta = require('../func.js');
const Client = require('instagram-private-api').V1;
const _ = require('lodash');
const chalk = require('chalk');

const getLastestMedia = async (session,userId) => {
  const feed = new Client.Feed.UserMedia(session, userId);
  try {
    const result = await feed.get();
    return result;
  } catch (err) {
    return err;
  }
}

const followFollowersTarget = async (session) => {
  const question = [
    {
      type:'input',
      name:'target',
      message:'Masukan Pengguna Yang Mau Di Follow Followernya [TANPA PAKAI @]',
      validate: function(value){
        if(!value) return 'Can\'t Empty';
        return true;
      }
    },
    {
      type:'input',
      name:'text',
      message:'Masukan Komen, pakai pemisah | untuk komen lebih dari 1  =',
      validate: function(value){
        if(!value) return 'Can\'t Empty';
        return true;
      }
    },
    {
      type:'input',
      name:'sleep',
      message:'Waktu Jeda (Per Detik)',
      validate: function(value){
        value = value.match(/[0-15]/);
        if (value) return true;
        return 'Delay is number';
      }
    }
  ]
  try {
    const answers = await inquirer.prompt(question);
    const requestOption = {
      url:'https://www.instagram.com/'+answers.target+'/?__a=1',
      json:true
    }
    var commentArray = answers.text.split('|');
    var cursor;
    var targetId = await rp(requestOption);
    targetId = targetId.user.id;
    const feeds = new Client.Feed.AccountFollowers(session, targetId);
    console.log('')
    do {
      if (cursor) feeds.setCursor(cursor);
      var targetPerson = await feeds.get();
      targetPerson = _.chunk(targetPerson, 15);
      for (targetPerson of targetPerson) {
        await Promise.all(targetPerson.map(async(targetPerson) Hasil {
          var timeNow = new Date();
          timeNow = `${timeNow.getHours()}:${timeNow.getMinutes()}:${timeNow.getSeconds()}`
          var ranComment = _.sample(commentArray);
          const media = await getLastestMedia(session, targetPerson.params.id);
          if (media.length > 0) {
            insta.setTargetId(targetPerson.params.id);
            const task = [
              
              insta.doLike(media[0].id) ? chalk`{bold.green SUKSES}` : chalk`{bold.red GAGAL}`,
              insta.doComment(media[0].id, ranComment) ? chalk`{bold.green SUKSES}` : chalk`{bold.red GAGAL}`
            ]
            const [like,comment] = await Promise.all(task);
            console.log(chalk`[{magenta ${timeNow}}] {cyanBright @${targetPerson.params.username}} Hasil  [Like: ${like}] [Comment: ${comment}({cyan ${ranComment}})]`);
          } else {
            console.log(chalk`[{magenta ${timeNow}}] {cyanBright @${targetPerson.params.username}} Hasil DILEWATI [PRIVATE/KOSONG]`);            
          }
        }));
        await insta.doSleep(answers.sleep, `Akan Mulai Lagi Dalam ${answers.sleep} Detik`);
      }
    } while(feeds.isMoreAvailable());
  } catch(e) {
    return Promise.reject(e);
  }
}

module.exports = followFollowersTarget;
