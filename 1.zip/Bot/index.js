'use strict'

const insta = require('./func.js');
const chalk = require('chalk');
const delay = require('delay');
const inquirer = require('inquirer');
const Spinner = require('cli-spinner').Spinner;

const questionLogin = [
  {
    type:'input',
    name:'username',
    message:'Masukan Username ig',
    validate: function(value){
      if(!value) return 'Can\'t Empty';
      return true;
    }
  },
  {
    type:'password',
    name:'password',
    message:'Password',
    mask:'*',
    validate: function(value){
      if(!value) return 'Can\'t Empty';
      return true;
    }
  }
]

const questionTools = [
  {
    type:"list",
    name:"Tools",
    message:"VIP BOT BY AING BONEK (TERMUX/HP) ",
    choices:
      [
        "Follow Followers Target",
        new inquirer.Separator(),
        "ME",
        "Tekan ENTER Untuk Melanjutkan"
      ] 
  }
]

const main = async () => {
  var spinner;
  try{
    const cridential = await inquirer.prompt(questionLogin);  
    spinner = new Spinner('Masuk Ke Dalam Akun. . .');
    spinner.setSpinnerString(4);
    spinner.start();
    const doLogin = await insta(cridential.username, cridential.password);
    spinner.stop(true);
    console.log(`\n\t Account Data`);
    console.log(`id akun\t\t\t: ${doLogin.account.id}\nUser Name\t\t: ${doLogin.account.username}\nNama Akun\t\t: ${doLogin.account.fullName}\n`);
    console.log(`Total Followers\t\t: ${doLogin.account.followerCount}\nTotal Following\t\t: ${doLogin.account.followingCount}\nTotal Media\t\t: ${doLogin.account.mediaCount}\n`);
    var toolChoise = await inquirer.prompt(questionTools);
    toolChoise = toolChoise.Tools;
    switch(toolChoise){
      case "Mengikuti Pengikut Pengguna":
        const followFollowersTarget = require('./Tools/followfollowerstarget.js');
        await followFollowersTarget(doLogin.session);
	break;
      case "ME":
        const me = require('./Tools/me.js');
        await followFollowersTarget(doLogin.session);
	break;
      default:
        console.log('Exit..');
    }
  } catch(e) {
    spinner.stop(true);
    console.log(e);
  }
}

console.log(chalk`
            		AIN BONEK 
    		BOT INSTAGRAM BY CAK BONEK
`)

main()
